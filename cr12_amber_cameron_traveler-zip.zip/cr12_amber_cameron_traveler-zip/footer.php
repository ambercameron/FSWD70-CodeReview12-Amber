<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cr12_amber_cameron_traveler.zip
 */

?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer bg-dark">
		<div class="site-info">
			<p class="text-white text-center">
				<?php
				/* translators: %s: CMS name, i.e. WordPress. */
				printf( esc_html__( 'Code Review 12 2019 - Amber Cameron' ));
				?>
			</p>
			<p class="text-white text-center">
				<?php
				/* translators: 1: Theme name, 2: Theme author. */
				printf( esc_html__( 'Theme: cr12_amber_cameron_traveler-zip'));
				?>
			</p>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
