<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package cr12_amber_cameron_traveler.zip
 */

get_header();
?>

	<div class="container-fluid">
		<div class="row justify-content-around align-items-center">

         <?php if(have_posts()) :  ?>  <!--if there are any posts-->
            <?php while(have_posts()) : the_post(); ?><!--while there are posts, show the posts-->
		<div class="col-10 col-md-5 col-xl-3 m-1">
          <div class="card border-0" style="width: 18rem;">
          <?php cr12_amber_cameron_traveler_zip_post_thumbnail(); ?>
           <h4 class="card-title text-center">
             <a class=" text-decoration-none text-center text-reset" href="<?php the_permalink(); ?>"> <!--retrieves URL for the permalink-->
              <?php the_title(); ?> </a></h4><!--retrieves blog title-->
			<div class="card-body">
				<p class="card-text">
            <?php the_excerpt(); ?><!--retrieves content-->
				</p>
				 <p class="card-text text-center mb-0"><?php the_time('F j, Y g:i a'); ?></p><!--retrieves date blog entry was created-->
			</div>
		</div>
		</div>
      <?php endwhile; ?> <!--end the while loop-->

            <?php else : ?> <!--if there are no posts-->
              <p><?php__('No Posts Found'); ?></p>
           <?php endif; ?><!--endif-->
       </div><!-- row -->
    </div><!-- container -->
<?php
      if(is_active_sidebar('sidebar')):
     dynamic_sidebar('sidebar');
     endif;  
?>
<?php
get_footer();
