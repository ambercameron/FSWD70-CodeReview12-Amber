<aside class="mh-sidebar">
	<?php dynamic_sidebar('sidebar'); ?>
</aside>